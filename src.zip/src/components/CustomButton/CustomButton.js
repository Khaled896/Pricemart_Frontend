import React from 'react';
import {View,Text,StyleSheet,Pressable} from 'react-native';

const CustomButton =()=>{

return (

    <Pressable onstyle={styles.container}>
    <Text style={styles.text}>Button</Text>

    </Pressable>
);


};


const styles=StyleSheet.create({

    container:{

        backgroundColor:'#008080',
        padding:15,
        width:'100%',
        borderRadius:5,
        marginVertical:5,
        alignItems:'center'
    },
    text:{

        fontweight:'bold',
        color:'white'
    },
});



export default CustomButton;